# Coding Bootcamp 9 – Learning Week 4 – JavaScript

> 2024/04/02 - 2024/04/04

Nella LW4 ci occupiamo principlamente di:

1. _tba_

### Learning goals

Potrai ritenere di aver completato con successo questo modulo quando sarai in grado di:

1. _tba_

### Completato?

Benissimo! Vai alla [LW5](../lw_05/README.md).
